import os
import datetime
import subprocess
import argparse
from ping3 import ping

from docker import cells

now = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
os.system('echo > This module can only be executed on the SSR network')


def mount(remote, local):
    command(f'mount {remote} {local}')


def command(cmd):
    return subprocess.run(cmd, shell=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--agent_version', type=str, required=True, help='Enter agent version (ex. 2.41.4841755)')
    parser.add_argument('-i', '--manager_ip', type=str, required=True, help='Enter manager ip (ex. 192.168.1.100')
    args = parser.parse_args()

    try:
        ping('192.168.1.112')
        os = 'linux'
        remote = f'192.168.1.112:/DATA1/lab/LAB/SolidStep/Agent/{args.agent_version}/{os}'
        path = '/mnt/ssr_mount'
        local = f'./tmp_{now}/{args.agent_version}'

        init = f'''\
FROM itzconnor/work:1.0

LABEL maintainer="Connor Kwon"
LABEL email1="kwonyounggyu@ssrinc.co.kr"
LABEL email2="connorkyg@gmail.com"
LABEL description="SSR Agent setup"


WORKDIR /

RUN apt update && apt-get install -y \
    python3.9 \
    python3-pip \
    nfs-common
RUN mkdir -p /SSR
COPY --chown=root:root {local} /SSR

# ENTRYPOINT python3 /tmp/docker/set_perm.py
# ENTRYPOINT python3 /tmp/docker/sacfg.py --SOLIDSTEP_MANAGER={args.manager_ip}
# ENTRYPOINT /SSR/SA-linux-64 --start

EXPOSE 443/tcp\
        '''

        # mkdir -> mount -> cp to local
        os.makedirs(path, exist_ok=True)
        os.makedirs(local, exist_ok=True)
        mount(remote, path)
        for file in cells.Agent:
            command(f'cp {path}/{file} {local}')

        with open(file='./dockerfile', mode='w+', encoding='utf-8') as f:
            f.write(init)

        command(f'docker build -t agent:{args.agent_version} .')
        command(f'umount -f {path}')
    except:
        print('[ERROR] Something went wrong')
        command(f'umount -f {path}')
